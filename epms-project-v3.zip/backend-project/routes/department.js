const express = require('express');
const router = express.Router();
const mysql = require('mysql2');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'epms'
});

router.post('/add', (req, res) => {
  const { name } = req.body;
  const sql = "INSERT INTO Department (name) VALUES (?)";
  db.query(sql, [name], (err, result) => {
    if (err) return res.status(500).send(err);
    res.send("Department added successfully");
  });
});

module.exports = router;
