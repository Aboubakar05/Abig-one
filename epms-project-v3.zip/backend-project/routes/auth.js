const express = require('express');
const router = express.Router();
const mysql = require('mysql2');
const bcrypt = require('bcrypt');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'epms'
});

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  const sql = "SELECT * FROM Users WHERE username = ?";
  db.query(sql, [username], (err, results) => {
    if (err) return res.status(500).send(err);
    if (results.length === 0) return res.status(401).send("User not found");

    const user = results[0];
    if (user.password === password) {
      req.session.user = user;
      res.send("Login successful");
    } else {
      res.status(401).send("Incorrect password");
    }
  });
});

router.get('/logout', (req, res) => {
  req.session.destroy();
  res.send("Logged out");
});

module.exports = router;
