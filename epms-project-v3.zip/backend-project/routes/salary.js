const express = require('express');
const router = express.Router();
const mysql = require('mysql2');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'epms'
});

router.post('/add', (req, res) => {
  const { employeeNumber, amount, month, year } = req.body;
  const sql = "INSERT INTO Salary (employeeNumber, amount, month, year) VALUES (?, ?, ?, ?)";
  db.query(sql, [employeeNumber, amount, month, year], (err, result) => {
    if (err) return res.status(500).send(err);
    res.send("Salary added successfully");
  });
});

module.exports = router;
