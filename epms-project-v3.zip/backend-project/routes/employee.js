const express = require('express');
const router = express.Router();
const mysql = require('mysql2');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'epms'
});

router.post('/add', (req, res) => {
  const { firstName, lastName, position, address, telephone, gender, hiredDate } = req.body;
  const sql = "INSERT INTO Employee (firstName, lastName, position, address, telephone, gender, hiredDate) VALUES (?, ?, ?, ?, ?, ?, ?)";
  db.query(sql, [firstName, lastName, position, address, telephone, gender, hiredDate], (err, result) => {
    if (err) return res.status(500).send(err);
    res.send("Employee added successfully");
  });
});

module.exports = router;
