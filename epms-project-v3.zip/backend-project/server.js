const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const session = require('express-session');

const app = express();

app.use(cors());
app.use(express.json());
app.use(session({
  secret: 'secret-key',
  resave: false,
  saveUninitialized: true
}));

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'epms'
});

db.connect(err => {
  if (err) throw err;
  console.log('Database connected');
});

app.use('/employee', require('./routes/employee'));

app.listen(3001, () => {
  console.log("Server running on port 3001");
});

app.use('/auth', require('./routes/auth'));
app.use('/employees', require('./routes/employees'));
app.use('/department', require('./routes/department'));
app.use('/salary', require('./routes/salary'));