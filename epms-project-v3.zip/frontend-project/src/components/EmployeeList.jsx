import React, { useEffect, useState } from 'react';
import axios from 'axios';

function EmployeeList() {
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3001/employees')
      .then(res => setEmployees(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Employee List</h2>
      <ul className="space-y-2">
        {employees.map(emp => (
          <li key={emp.employeeNumber} className="border p-2 rounded">
            {emp.firstName} {emp.lastName} - {emp.position}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default EmployeeList;
