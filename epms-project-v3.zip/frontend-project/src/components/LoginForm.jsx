import React, { useState } from 'react';
import axios from 'axios';

function LoginForm() {
  const [form, setForm] = useState({ username: '', password: '' });

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = e => {
    e.preventDefault();
    axios.post('http://localhost:3001/auth/login', form)
      .then(res => alert(res.data))
      .catch(err => alert("Login failed"));
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 space-y-4">
      <input type="text" name="username" placeholder="Username" onChange={handleChange} className="border p-2 w-full" />
      <input type="password" name="password" placeholder="Password" onChange={handleChange} className="border p-2 w-full" />
      <button type="submit" className="bg-green-500 text-white px-4 py-2">Login</button>
    </form>
  );
}

export default LoginForm;
