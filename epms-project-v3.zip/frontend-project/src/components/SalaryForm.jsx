import React, { useState } from 'react';
import axios from 'axios';

function SalaryForm() {
  const [form, setForm] = useState({
    employeeNumber: '',
    amount: '',
    month: '',
    year: ''
  });

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = e => {
    e.preventDefault();
    axios.post('http://localhost:3001/salary/add', form)
      .then(res => alert(res.data))
      .catch(err => console.error(err));
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 space-y-4">
      <input name="employeeNumber" placeholder="Employee Number" onChange={handleChange} className="border p-2 w-full" />
      <input name="amount" placeholder="Salary Amount" onChange={handleChange} className="border p-2 w-full" />
      <input name="month" placeholder="Month" onChange={handleChange} className="border p-2 w-full" />
      <input name="year" placeholder="Year" onChange={handleChange} className="border p-2 w-full" />
      <button type="submit" className="bg-yellow-500 text-white px-4 py-2">Add Salary</button>
    </form>
  );
}

export default SalaryForm;
