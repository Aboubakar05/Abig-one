import React, { useState } from 'react';
import axios from 'axios';

function EmployeeForm() {
  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    position: '',
    address: '',
    telephone: '',
    gender: '',
    hiredDate: ''
  });

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = e => {
    e.preventDefault();
    axios.post('http://localhost:3001/employee/add', form)
      .then(res => alert(res.data))
      .catch(err => console.error(err));
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 space-y-4">
      <input type="text" name="firstName" onChange={handleChange} placeholder="First Name" className="border p-2 w-full" />
      <input type="text" name="lastName" onChange={handleChange} placeholder="Last Name" className="border p-2 w-full" />
      <input type="text" name="position" onChange={handleChange} placeholder="Position" className="border p-2 w-full" />
      <input type="text" name="address" onChange={handleChange} placeholder="Address" className="border p-2 w-full" />
      <input type="text" name="telephone" onChange={handleChange} placeholder="Telephone" className="border p-2 w-full" />
      <select name="gender" onChange={handleChange} className="border p-2 w-full">
        <option value="">Select Gender</option>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
      </select>
      <input type="date" name="hiredDate" onChange={handleChange} className="border p-2 w-full" />
      <button type="submit" className="bg-blue-500 text-white px-4 py-2">Save</button>
    </form>
  );
}

export default EmployeeForm;
