const express = require('express');
const router = express.Router();
const db = require('../utils/db');

// Add Salary
router.post('/', (req, res) => {
  const { employeeId, basicSalary, deductions, bonuses, paymentDate } = req.body;
  const sql = 'INSERT INTO Salary (employeeId, basicSalary, deductions, bonuses, paymentDate) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [employeeId, basicSalary, deductions, bonuses, paymentDate], (err, result) => {
    if (err) throw err;
    res.send({ message: 'Salary added' });
  });
});

// Generate monthly report
router.get('/report/:month', (req, res) => {
  const month = req.params.month;
  const sql = \`
    SELECT 
      CONCAT(e.firstName, ' ', e.lastName) AS employeeName,
      s.basicSalary,
      s.deductions,
      s.bonuses,
      (s.basicSalary - s.deductions + s.bonuses) AS totalSalary
    FROM 
      Salary s
      JOIN Employee e ON s.employeeId = e.employeeId
    WHERE 
      DATE_FORMAT(s.paymentDate, '%Y-%m') = ?
  \`;

  db.query(sql, [month], (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

module.exports = router;