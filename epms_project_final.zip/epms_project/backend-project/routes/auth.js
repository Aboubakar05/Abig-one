const express = require('express');
const router = express.Router();
const db = require('../utils/db');

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  const sql = 'SELECT * FROM Users WHERE username = ? AND password = ?';
  db.query(sql, [username, password], (err, results) => {
    if (err) throw err;
    if (results.length > 0) {
      req.session.user = results[0];
      res.send({ message: 'Login successful' });
    } else {
      res.status(401).send({ message: 'Invalid credentials' });
    }
  });
});

router.get('/logout', (req, res) => {
  req.session.destroy();
  res.send({ message: 'Logged out' });
});

module.exports = router;