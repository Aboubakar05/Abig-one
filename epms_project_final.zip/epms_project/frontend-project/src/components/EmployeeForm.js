import React, { useState } from 'react';
import axios from 'axios';

function EmployeeForm() {
  const [formData, setFormData] = useState({});

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    await axios.post('http://localhost:5000/api/employees', formData);
    alert('Employee added');
  };

  return (
    <div>
      <h2>Add Employee</h2>
      <input name='firstName' placeholder='First Name' onChange={handleChange} />
      <input name='lastName' placeholder='Last Name' onChange={handleChange} />
      <input name='position' placeholder='Position' onChange={handleChange} />
      <input name='address' placeholder='Address' onChange={handleChange} />
      <input name='telephone' placeholder='Telephone' onChange={handleChange} />
      <input name='gender' placeholder='Gender' onChange={handleChange} />
      <input name='hireDate' type='date' onChange={handleChange} />
      <input name='departmentCode' placeholder='Department Code' onChange={handleChange} />
      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
}
export default EmployeeForm;