import React, { useState } from 'react';
import axios from 'axios';

function SalaryForm() {
  const [formData, setFormData] = useState({});

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    await axios.post('http://localhost:5000/api/salaries', formData);
    alert('Salary record added');
  };

  return (
    <div>
      <h2>Add Salary</h2>
      <input name='employeeId' placeholder='Employee ID' onChange={handleChange} />
      <input name='basicSalary' placeholder='Basic Salary' onChange={handleChange} />
      <input name='deductions' placeholder='Deductions' onChange={handleChange} />
      <input name='bonuses' placeholder='Bonuses' onChange={handleChange} />
      <input name='paymentDate' type='date' onChange={handleChange} />
      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
}
export default SalaryForm;