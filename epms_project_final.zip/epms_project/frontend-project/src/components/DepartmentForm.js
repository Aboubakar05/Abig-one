import React, { useState } from 'react';
import axios from 'axios';

function DepartmentForm() {
  const [departmentCode, setDepartmentCode] = useState('');
  const [departmentName, setDepartmentName] = useState('');

  const handleSubmit = async () => {
    await axios.post('http://localhost:5000/api/departments', {
      departmentCode,
      departmentName
    });
    alert('Department added');
  };

  return (
    <div>
      <h2>Add Department</h2>
      <input placeholder='Department Code' onChange={e => setDepartmentCode(e.target.value)} />
      <input placeholder='Department Name' onChange={e => setDepartmentName(e.target.value)} />
      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
}
export default DepartmentForm;