import React from 'react';
import EmployeeForm from './EmployeeForm';
function Dashboard() {
  return (
    <div>
      <h1>Employee Payroll Management System</h1>
      <EmployeeForm />
    </div>
  );
}
export default Dashboard;