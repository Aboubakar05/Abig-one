import React, { useState, useEffect } from 'react';
import axios from 'axios';

function MonthlyPayrollReport() {
  const [reports, setReports] = useState([]);
  const [month, setMonth] = useState('');

  const fetchReport = async () => {
    const response = await axios.get(\`http://localhost:5000/api/salaries/report/\${month}\`);
    setReports(response.data);
  };

  return (
    <div>
      <h2>Monthly Payroll Report</h2>
      <input
        type="month"
        value={month}
        onChange={(e) => setMonth(e.target.value)}
      />
      <button onClick={fetchReport}>Generate Report</button>

      <table>
        <thead>
          <tr>
            <th>Employee</th>
            <th>Basic Salary</th>
            <th>Deductions</th>
            <th>Bonuses</th>
            <th>Total Salary</th>
          </tr>
        </thead>
        <tbody>
          {reports.map((r, index) => (
            <tr key={index}>
              <td>{r.employeeName}</td>
              <td>{r.basicSalary}</td>
              <td>{r.deductions}</td>
              <td>{r.bonuses}</td>
              <td>{r.totalSalary}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
export default MonthlyPayrollReport;