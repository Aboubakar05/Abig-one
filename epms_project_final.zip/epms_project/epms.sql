CREATE DATABASE IF NOT EXISTS epms;
USE epms;

CREATE TABLE IF NOT EXISTS Department (
  departmentCode VARCHAR(10) PRIMARY KEY,
  departmentName VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS Employee (
  employeeId INT AUTO_INCREMENT PRIMARY KEY,
  firstName VARCHAR(50),
  lastName VARCHAR(50),
  position VARCHAR(50),
  address VARCHAR(100),
  telephone VARCHAR(20),
  gender VARCHAR(10),
  hireDate DATE,
  departmentCode VARCHAR(10),
  FOREIGN KEY (departmentCode) REFERENCES Department(departmentCode)
);

CREATE TABLE IF NOT EXISTS Salary (
  salaryId INT AUTO_INCREMENT PRIMARY KEY,
  employeeId INT,
  basicSalary DECIMAL(10,2),
  deductions DECIMAL(10,2),
  bonuses DECIMAL(10,2),
  paymentDate DATE,
  FOREIGN KEY (employeeId) REFERENCES Employee(employeeId)
);

CREATE TABLE IF NOT EXISTS Users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50),
  password VARCHAR(50)
);

INSERT INTO Users (username, password) VALUES ('admin', 'admin123');